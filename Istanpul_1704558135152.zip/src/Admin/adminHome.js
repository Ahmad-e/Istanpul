const AdminHome =()=>{

    return(
        <div>
            Home
        </div>
    )
}
export default AdminHome