const Sales =()=>{
    return(
        <div>
            Sale
        </div>
    )
}
export default Sales