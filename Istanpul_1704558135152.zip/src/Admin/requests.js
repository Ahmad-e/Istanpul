const AdminRequests =()=>{
    return(
        <div>
            AdminRequests
        </div>
    )
}
export default AdminRequests